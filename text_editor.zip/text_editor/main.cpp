#include <iostream>
#include "textEditor.h"

using namespace std;

int main() {
    ListParagraph permanent, temp;
    createListParagraph(&permanent);
    createListParagraph(&temp);

    Stack undoStack, redoStack;
    createStack(&undoStack);
    createStack(&redoStack);

    int choice;
    do {
        cout << "\n=== Text Editor Menu ===" << endl;
        cout << "1. Tambah Paragraf Baru" << endl;
        cout << "2. Tambah Kata ke Paragraf" << endl;
        cout << "3. Save Perubahan" << endl;
        cout << "4. Tampilkan Semua Paragraf" << endl;
        cout << "5. Cari Kata" << endl;
        cout << "6. Edit Kata di Paragraf" << endl;
        cout << "7. Word Count" << endl;
        cout << "8. Undo" << endl;
        cout << "9. Redo" << endl;
        cout << "10. Keluar" << endl;
        cout << "Pilih opsi: ";
        cin >> choice;

        switch (choice) {
            case 1: {
                push(&undoStack, temp);
                while (!isEmpty(&redoStack)) pop(&redoStack);

                string paragraph_id;
                cout << "Masukkan ID Paragraf: ";
                cin.ignore();
                getline(cin, paragraph_id);

                insertParagraph(&temp, paragraph_id);
                cout << "Paragraf baru berhasil ditambahkan (belum disimpan)!" << endl;
                break;
            }
            case 2: {
                push(&undoStack, temp);
                while (!isEmpty(&redoStack)) pop(&redoStack);

                string paragraph_id, word;
                cout << "Masukkan ID Paragraf: ";
                cin.ignore();
                getline(cin, paragraph_id);

                cout << "Masukkan Kata: ";
                getline(cin, word);

                addWordToParagraph(&temp, paragraph_id, word);
                cout << "Kata berhasil ditambahkan (belum disimpan)!" << endl;
                break;
            }
            case 3: {
                string paragraph_id;
                cout << "Masukkan ID Paragraf yang ingin disimpan: ";
                cin.ignore();
                getline(cin, paragraph_id);

                saveParagraph(&permanent, &temp, paragraph_id);
            break;
            }

            case 4: {
                cout << "\n=== Paragraf Permanen ===" << endl;
                printAll(permanent);
                cout << "\n=== Paragraf Sementara ===" << endl;
                printAll(temp);
                break;
            }
            case 5: {
                string word;
                cout << "Masukkan Kata yang Dicari: ";
                cin.ignore();
                getline(cin, word);

                searchWord(permanent, word);
                break;
            }
            case 6: {
                string paragraph_id;
                int position, actionChoice;

                cout << "Masukkan ID Paragraf: ";
                cin.ignore();
                getline(cin, paragraph_id);

                cout << "Pilih Aksi Editing:" << endl;
                cout << "1. Sisipkan Kata" << endl;
                cout << "2. Hapus Kata" << endl;
                cout << "Pilih opsi: ";
                cin >> actionChoice;

                if (actionChoice == 1) {
                    string newWord;
                    cout << "Masukkan Posisi Kata: ";
                    cin >> position;
                    cout << "Masukkan Kata Baru: ";
                    cin.ignore();
                    getline(cin, newWord);

                    editText(&temp, paragraph_id, position, newWord);
                    cout << "Kata berhasil disisipkan (belum disimpan)!" << endl;

                } else if (actionChoice == 2) {
                    cout << "Masukkan Posisi Kata yang Akan Dihapus: ";
                    cin >> position;

                    deleteWordInParagraph(&temp, paragraph_id, position);
                    cout << "Kata berhasil dihapus (belum disimpan)!" << endl;

                } else {
                    cout << "Pilihan tidak valid!" << endl;
                }
                break;
            }
            case 7: { // Word Count
                int total = wordCount(permanent);
                cout << "Total kata di semua paragraf permanen: " << total << endl;
                break;
            }
            case 8: {
                if (!isEmpty(&undoStack)) {
                    temp = pop(&undoStack);
                    push(&redoStack, temp);
                    cout << "Undo berhasil!" << endl;
                } else {
                    cout << "Tidak ada tindakan yang bisa di-undo!" << endl;
                }
                break;
            }
            case 9: {
                if (!isEmpty(&redoStack)) {
                    push(&undoStack, temp);
                    temp = pop(&redoStack);
                    cout << "Redo berhasil!" << endl;
                } else {
                    cout << "Tidak ada tindakan yang bisa di-redo!" << endl;
                }
                break;
            }
            case 10: {
                cout << "Keluar dari program. Terima kasih!" << endl;
                break;
            }
            default:
                cout << "Pilihan tidak valid. Silakan coba lagi." << endl;
        }
    } while (choice != 10);

    return 0;
}
