#include "textEditor.h"
#include <iostream>
#include <sstream>

using namespace std;

void createListParagraph(ListParagraph *L){
    /* I.S. -
       F.S. Dihasilkan sebuah ListParagraph kosong dengan pointer first dan last bernilai nullptr */

    L->first = nullptr; // Set pointer first ke null
    L->last = nullptr; // Set pointer last ke null
}

void createListWord(ListWord *L){
     /* I.S. -
       F.S. Dihasilkan sebuah ListWord kosong dengan pointer first bernilai nullptr */

    L->first = nullptr; // Set pointer first ke null
}


AdrWord createWordElement(Infotype word){
    /* I.S. Tidak ada elemen untuk kata
       F.S. Sebuah elemen kata baru berhasil dibuat, dengan info = word dan next = nullptr */

    AdrWord newWord = new ElmWord; // Alokasi memori untuk elemen baru
    newWord->info = word;          // Mengisi elemen dengan data kata
    newWord->next = nullptr;       // Pointer next diset ke null
    return newWord;
}

AdrParagraph createParagraphElement(Infotype paragraph_id){
    /* I.S. Tidak ada elemen untuk paragraf
       F.S. Sebuah elemen paragraf baru berhasil dibuat, dengan info.paragraph_id = paragraph_id,
            words sebagai ListWord kosong, next = nullptr, dan prev = nullptr */

    AdrParagraph newParagraph = new ElmParagraph;   // Alokasi memori untuk elemen baru
    newParagraph->info.paragraph_id = paragraph_id; // Mengisi ID paragraf
    createListWord(&newParagraph->info.words);      // Inisialisasi list kata kosong
    newParagraph->next = nullptr;                   // Pointer next diset ke null
    newParagraph->prev = nullptr;                   // Pointer prev diset ke null
    return newParagraph;
}


void insertParagraph(ListParagraph *L, Infotype id){
   AdrParagraph newParagraph = createParagraphElement(id);
    if (L->first == nullptr) {
        L->first = newParagraph;
        L->last = newParagraph;
    } else {
        L->last->next = newParagraph;
        newParagraph->prev = L->last;
        L->last = newParagraph;
    }
}
void insertWord(ListWord *L, Infotype word){
   AdrWord newWord = createWordElement(word);
    if (L->first == nullptr) {
        L->first = newWord;
    } else {
        AdrWord temp = L->first;
        while (temp->next != nullptr) {
            temp = temp->next;
        }
        temp->next = newWord;
    }
}

AdrParagraph searchParagraph(ListParagraph L, Infotype id){
    AdrParagraph current = L.first;
    while (current != nullptr) {
        if (current->info.paragraph_id == id) {
            return current;
        }
        current = current->next;
    }
    return nullptr;
}

void saveParagraph(ListParagraph *permanent, ListParagraph *temp, Infotype paragraph_id) {
    if (temp->first == nullptr) {
        cout << "Tidak ada perubahan yang perlu disimpan." << endl;
        return;
    }

    AdrParagraph tempNode = searchParagraph(*temp, paragraph_id);
    if (tempNode == nullptr) {
        cout << "Paragraf dengan ID '" << paragraph_id << "' tidak ditemukan di paragraf sementara." << endl;
        return;
    }

    AdrParagraph newParagraph = createParagraphElement(tempNode->info.paragraph_id);

    AdrWord currentWord = tempNode->info.words.first;
    while (currentWord != nullptr) {
        insertWord(&newParagraph->info.words, currentWord->info);
        currentWord = currentWord->next;
    }

    if (permanent->first == nullptr) {
        permanent->first = newParagraph;
        permanent->last = newParagraph;
    } else {
        permanent->last->next = newParagraph;
        newParagraph->prev = permanent->last;
        permanent->last = newParagraph;
    }

    deleteParagraph(temp, paragraph_id);

    cout << "Paragraf dengan ID '" << paragraph_id << "' berhasil disimpan ke permanen." << endl;
}

void addWordToParagraph(ListParagraph *L, Infotype paragraph_id, Infotype word) {
    AdrParagraph target = searchParagraph(*L, paragraph_id);
    if (target != nullptr) {
        insertWord(&target->info.words, word);
    } else {
        cout << "Paragraf dengan ID '" << paragraph_id << "' tidak ditemukan!" << endl;
    }
}

void deleteParagraph(ListParagraph *L, Infotype id) {
    AdrParagraph target = L->first;

    while (target != nullptr && target->info.paragraph_id != id) {
        target = target->next;
    }

    if (target == nullptr) {
        cout << "Paragraf dengan ID '" << id << "' tidak ditemukan!" << endl;
        return;
    }

    if (target == L->first) {
        L->first = target->next;
        if (L->first != nullptr) L->first->prev = nullptr;
    }
    else if (target == L->last) {
        L->last = target->prev;
        if (L->last != nullptr) L->last->next = nullptr;
    }
    else {
        target->prev->next = target->next;
        target->next->prev = target->prev;
    }

    delete target;
    cout << "Paragraf berhasil dihapus!" << endl;
}

void searchWord(ListParagraph L, Infotype word){
    AdrParagraph currentParagraph = L.first;
    int paragraphIndex = 1;
    bool found = false;

    while (currentParagraph != nullptr) {
        AdrWord currentWord = currentParagraph->info.words.first;
        int wordIndex = 1;
        bool paragraphFound = false;

        while (currentWord != nullptr) {
            if (currentWord->info == word) {
                if (!paragraphFound) {
                    cout << "Kata '" << word << "' ditemukan di Paragraf " << paragraphIndex << " pada posisi: ";
                    paragraphFound = true;
                }
                cout << wordIndex << " ";
                found = true;
            }
            currentWord = currentWord->next;
            wordIndex++;
        }

        if (paragraphFound) {
            cout << endl;
        }
        currentParagraph = currentParagraph->next;
        paragraphIndex++;
    }

    if (!found) {
        cout << "Kata '" << word << "' tidak ditemukan di paragraf manapun." << endl;
    }
}
void editText(ListParagraph *L, Infotype paragraphID, int position, Infotype newWord) {
    AdrParagraph targetParagraph = searchParagraph(*L, paragraphID);
    if (targetParagraph == nullptr) {
        cout << "Paragraf dengan ID '" << paragraphID << "' tidak ditemukan." << endl;
        return;
    }

    AdrWord newElm = createWordElement(newWord);
    AdrWord current = targetParagraph->info.words.first;

    if (position == 1) {
        newElm->next = current;
        targetParagraph->info.words.first = newElm;
    } else {
        int index = 1;
        AdrWord prev = nullptr;
        while (current != nullptr && index < position) {
            prev = current;
            current = current->next;
            index++;
        }

        if (index != position) {
            cout << "Posisi tidak valid, gagal menyisipkan kata." << endl;
            delete newElm;
            return;
        }

        prev->next = newElm;
        newElm->next = current;
    }

    cout << "Kata '" << newWord << "' berhasil disisipkan di Paragraf '" << paragraphID << "' pada posisi " << position << "." << endl;
}

void printAll(ListParagraph L) {
    /* I.S. Terdefinisi ListParagraph L yang berisi elemen-elemen paragraf
       F.S. Seluruh paragraf dalam L, beserta kata-kata di dalamnya, ditampilkan ke layar.
            Jika tidak ada paragraf, akan ditampilkan pesan "tidak ada paragraf." */

    // Kamus Data:
    // currentParagraph : AdrParagraph (pointer untuk traversal pada ListParagraph)
    // currentWord      : AdrWord (pointer untuk traversal pada ListWord di tiap paragraf)

    // Algoritma:
    AdrParagraph currentParagraph = L.first;
    if (currentParagraph == nullptr) {
        cout << "Tidak ada paragraf." << endl;
        return;
    }

    while (currentParagraph != nullptr) {
        cout << "Paragraf: " << currentParagraph->info.paragraph_id << endl;

        AdrWord currentWord = currentParagraph->info.words.first;
        if (currentWord == nullptr) {
            cout << "  (Tidak ada kata)" << endl;
        } else {
            while (currentWord != nullptr) {
                cout << currentWord->info << " ";
                currentWord = currentWord->next;
            }
            cout << endl;
        }
        currentParagraph = currentParagraph->next;
    }
}

int wordCount(ListParagraph L) {
    int totalWords = 0;
    AdrParagraph currentParagraph = L.first;

    // Traversal setiap paragraf
    while (currentParagraph != nullptr) {
        AdrWord currentWord = currentParagraph->info.words.first;

        // Hitung jumlah kata dalam setiap ListWord
        while (currentWord != nullptr) {
            totalWords++;
            currentWord = currentWord->next;
        }

        currentParagraph = currentParagraph->next;
    }

    return totalWords; // Mengembalikan total kata
}


void deleteWordInParagraph(ListParagraph *L, Infotype paragraphID, int position) {
    /* I.S. Terdefinisi ListParagraph L dan posisi kata yang ingin dihapus.
       F.S. Kata pada posisi tertentu dihapus dari paragraf jika valid. */

    AdrParagraph targetParagraph = searchParagraph(*L, paragraphID);
    if (targetParagraph == nullptr) {
        cout << "Paragraf dengan ID '" << paragraphID << "' tidak ditemukan." << endl;
        return;
    }

    AdrWord current = targetParagraph->info.words.first;
    AdrWord prev = nullptr;
    int index = 1;

    while (current != nullptr && index < position) {
        prev = current;
        current = current->next;
        index++;
    }

    if (current == nullptr) {
        cout << "Posisi tidak valid. Kata tidak ditemukan." << endl;
        return;
    }

    if (prev == nullptr) {
        targetParagraph->info.words.first = current->next;
    } else {
        prev->next = current->next;
    }

    delete current;
    cout << "Kata pada posisi " << position << " berhasil dihapus dari Paragraf '" << paragraphID << "'." << endl;
}

void createStack(Stack* s) {
    s->top = nullptr;
}

bool isEmpty(Stack* s) {
    return s->top == nullptr;
}

void push(Stack* s, ListParagraph data) {
    StackNode* newNode = new StackNode;
    newNode->data = data;
    newNode->next = s->top;
    s->top = newNode;
}

ListParagraph pop(Stack* s) {
    if (isEmpty(s)) {
        cout << "Stack kosong!" << endl;
        ListParagraph empty;
        createListParagraph(&empty);
        return empty;
    }
    StackNode* temp = s->top;
    ListParagraph data = temp->data;
    s->top = temp->next;
    delete temp;
    return data;
}

ListParagraph peek(Stack* s) {
    if (!isEmpty(s)) {
        return s->top->data;
    } else {
        ListParagraph empty;
        createListParagraph(&empty);
        return empty;
    }
}

void deleteLastAction(ListAction *L);
