#ifndef TEXTEDITOR_H_INCLUDED
#define TEXTEDITOR_H_INCLUDED

#include <string>

using namespace std;

typedef string Infotype;

typedef struct ElmWord *AdrWord;

typedef struct ElmWord {
    Infotype info;
    AdrWord next;
};

typedef struct ListWord{
    AdrWord first;
};

typedef struct InfotypeParagraph{
    Infotype paragraph_id;
    ListWord words;
};

typedef struct ElmParagraph *AdrParagraph;

typedef struct ElmParagraph {
    InfotypeParagraph info;
    AdrParagraph next;
    AdrParagraph prev;
};

typedef struct ListParagraph{
    AdrParagraph first;
    AdrParagraph last;
};

typedef struct InfotypeAction{
    Infotype action;
    ListParagraph state;
};

typedef struct ElmAction *AdrAction;

typedef struct ElmAction {
    InfotypeAction info;
    AdrAction next;
    AdrAction prev;
};

typedef struct ListAction{
    AdrAction first;
    AdrAction last;
};

struct StackNode {
    ListParagraph data;
    StackNode* next;
};

struct Stack {
    StackNode* top;
};


void createListParagraph(ListParagraph *L);
void createListWord(ListWord *L);
AdrWord createWordElement(Infotype word);
AdrParagraph createParagraphElement(Infotype paragraph_id);
void insertParagraph(ListParagraph *L, Infotype id);
void insertWord(ListWord *L, Infotype word);
void saveParagraph(ListParagraph *permanent, ListParagraph *temp, Infotype paragraph_id);
void addWordToParagraph(ListParagraph *L, Infotype paragraph_id, Infotype word);
void deleteParagraph(ListParagraph *L, Infotype id);
void deleteLastAction(ListAction *L);
AdrParagraph searchParagraph(ListParagraph L, Infotype id);
void searchWord(ListParagraph L, Infotype word);
void editText(ListParagraph *L, Infotype paragraphID, int position, Infotype newWord);
void deleteWordInParagraph(ListParagraph *L, Infotype paragraphID, int position);
void printAll(ListParagraph L);
int wordCount(ListParagraph L);
ListParagraph peek(Stack* s);
ListParagraph pop(Stack* s);
void push(Stack* s, ListParagraph data);
bool isEmpty(Stack* s);
void createStack(Stack* s);


#endif // TEXTEDITOR_H_INCLUDED
